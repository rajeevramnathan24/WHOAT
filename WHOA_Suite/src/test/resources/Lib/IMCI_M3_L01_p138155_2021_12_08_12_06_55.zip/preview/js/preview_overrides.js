/* globals MobileEsp, OUTPUT_MODE_CHECKER, VARIABLES_HOLDER, EM, GOMO_PREVIEW, LOADER, $, SCREEN_INTERACTIONS */
/* eslint-disable new-cap */

var _booIsSmartphone = MobileEsp.DetectSmartphone();
var _booIsTablet = MobileEsp.DetectTierTablet();

window.GOMO_PREVIEW = (function() {
  /**
   * Preview - centralises all preview related tasks
   */
  var Preview = function() {
  };

  Preview.prototype = {
    dataPollingInterval: 30000,
    init: function() {
      var me = this;
      // Set the flag in the player for Preview mode
      OUTPUT_MODE_CHECKER.setPreviewMode(true);

      me.extenedVariablesHolder();
      me.setListeners();
    },

    extenedVariablesHolder: function() {
      if (!_booIsSmartphone && !_booIsTablet) {
        VARIABLES_HOLDER._booResizeHandlerAssigned = false;

        VARIABLES_HOLDER.handleEvent_outputModeChanged = function(_objEventData) {
          var _strNewOutputMode = _objEventData['strNewOutputMode'];
          var _strCurrAccessibilityState = this.getVariableValue('gomo_accessibility_state');
          var _arrChangedVariables = [];

          switch (_strNewOutputMode) {
            case 'graphicalC':
              if (_strCurrAccessibilityState == 'true') {
                EM.trigger('updateVariableValue', {
                  strVariableName: 'gomo_accessibility_state',
                  strVariableValue: 'false',
                  strCallbackEvent: false,
                  booIsSystemVariable: true
                });
                _arrChangedVariables.push('gomo_accessibility_state');
              }
              break;
            case 'accessibleC':
              if (_strCurrAccessibilityState == 'false') {
                EM.trigger('updateVariableValue', {
                  strVariableName: 'gomo_accessibility_state',
                  strVariableValue: 'true',
                  strCallbackEvent: false,
                  booIsSystemVariable: true
                });
                _arrChangedVariables.push('gomo_accessibility_state');
              }
              break;
            case 'smartphoneC':
              if (_strCurrAccessibilityState == 'true') {
                EM.trigger('updateVariableValue', {
                  strVariableName: 'gomo_accessibility_state',
                  strVariableValue: 'false',
                  strCallbackEvent: false,
                  booIsSystemVariable: true
                });
                _arrChangedVariables.push('gomo_accessibility_state');
              }
              break;
            case 'tabletC':
              if (_strCurrAccessibilityState == 'true') {
                EM.trigger('updateVariableValue', {
                  strVariableName: 'gomo_accessibility_state',
                  strVariableValue: 'false',
                  strCallbackEvent: false,
                  booIsSystemVariable: true
                });
                _arrChangedVariables.push('gomo_accessibility_state');
              }
              break;
            default:
              alert(
                'ERROR: Unknown output mode of \'' +
                  _strNewOutputMode +
                  '\' found in handleEvent_outputModeChanged, variables_holder.js'
              );
              break;
          }

          this._checkPreviewScreenWidth(_arrChangedVariables);

          if (!this._booResizeHandlerAssigned) {
            $(window).resize(function() {
              VARIABLES_HOLDER._checkPreviewScreenWidth([]);
            });
            this._booResizeHandlerAssigned = true;
          }
        };

        VARIABLES_HOLDER._checkPreviewScreenWidth = function(_arrChangedVariables) {
          var _strCurrDeviceType = this.getVariableValue('gomo_device_type');

          var _objFrameSize = OUTPUT_MODE_CHECKER.getScreenDimensions();
          var _intScreenWidth = _objFrameSize['intViewportWidth'];

          if (_intScreenWidth > 800) {
            if (_strCurrDeviceType != 'desktop') {
              EM.trigger('updateVariableValue', {
                strVariableName: 'gomo_device_type',
                strVariableValue: 'desktop',
                strCallbackEvent: false,
                booIsSystemVariable: true
              });
              _arrChangedVariables.push('gomo_device_type');
            }
          }
          if (_intScreenWidth <= 800 && _intScreenWidth > 500) {
            if (_strCurrDeviceType != 'tabletC') {
              EM.trigger('updateVariableValue', {
                strVariableName: 'gomo_device_type',
                strVariableValue: 'tablet',
                strCallbackEvent: false,
                booIsSystemVariable: true
              });
              _arrChangedVariables.push('gomo_device_type');
            }
          }
          if (_intScreenWidth <= 500) {
            if (_strCurrDeviceType != 'smartphoneC') {
              EM.trigger('updateVariableValue', {
                strVariableName: 'gomo_device_type',
                strVariableValue: 'smartphone',
                strCallbackEvent: false,
                booIsSystemVariable: true
              });
              _arrChangedVariables.push('gomo_device_type');
            }
          }

          if (_arrChangedVariables.length > 0) {
            var variableMatch = false;
            var countVariables = 0;
            while (countVariables < _arrChangedVariables.length) {
              // We don't want to updates the display on accessible state change as this will get rerendered anyway
              if (_arrChangedVariables[countVariables] == 'gomo_accessibility_state') {
                variableMatch = true;
                break;
              }
              countVariables++;
            }

            EM.trigger('systemVariablesChanged', {
              arrChangedSystemVariables: _arrChangedVariables,
              suppressDomUpdates: variableMatch
            });
          }
        };
      }
    },

    sendCurrentScreen: function(objCurrentTopicIdScreenId) {
      // targetOrigin = domain of the parent, * = any this is fine as we're checking origin in preview controller
      var message = {
        type: 'setTopicAndScreenId',
        data: objCurrentTopicIdScreenId
      };
      parent.postMessage(JSON.stringify(message), '*');
    },

    setListeners: function() {
      var eventMethod = window.addEventListener ? 'addEventListener' : 'attachEvent';
      var eventer = window[eventMethod];
      var messageEvent = eventMethod === 'attachEvent' ? 'onmessage' : 'message';
      eventer(messageEvent, function(e) {
        // validate the message is sent from a gomo domain or docker
        if (e.origin !== 'http://nginx' && e.origin.indexOf('gomolearning.com') === -1) return;
        if (e.data) {
          var messageData = JSON.parse(e.data);
          if (messageData && messageData.type) {
            switch (messageData.type) {
              case 'goToScreen': {
                GOMO_PREVIEW.goToScreen(messageData);
                break;
              }
              case 'switchLanguage': {
                GOMO_PREVIEW.switchLanguage(messageData);
                break;
              }
              case 'switchDeviceType': {
                GOMO_PREVIEW.switchDeviceType(messageData);
                break;
              }
            }
          }
        }
      });
    },

    switchLanguage: function(messageData) {
      if (gomo && gomo.translationManager) {
        var callbackFun = function() {};
        gomo.translationManager.setTranslation(messageData.languageId, true, callbackFun);
      }
    },

    switchDeviceType: function(messageData) {
      OUTPUT_MODE_CHECKER.setDeviceType(messageData.deviceType);
      // The new device may require iScroll so we will attempt to enable it
      SCREEN_INTERACTIONS.applyIscrollToCurrentScreen();
    },

    goToScreen: function(messageData) {
      if (EM) {
        EM.trigger('processActions', messageData.actions);
      }
    },

    triggerPlayerLoaded: function() {
      var me = this;

      var message = {
        type: 'hasPlayerLoaded',
        data: LOADER.booLoadSequenceComplete
      };
      parent.postMessage(JSON.stringify(message), '*');

      me.triggerProjectUpdatePolling();
    },

    triggerProjectUpdatePolling: function() {
      var me = this;

      var queryString = window.location.search.substring(1);
      var params = queryString.split('&');

      // Get the query parameters
      for (var i=0; i<params.length; i++) {
        var paramName = params[i].split('=');
        if (paramName.length > 0) {
          var paramValue = paramName[1];
          // Get the parameter name
          // and test first character for ?
          paramName = paramName[0];
          paramName = paramName[0] == '?' ? paramName.substr(1) : paramName;

          if (paramName === 'autoUpdate' && paramValue && JSON.parse(paramValue)) {
            me.dataPollingInterval = setInterval(function() {
              me.pollProjectUpdates();
            }, me.dataPollingInterval);
          }
        }
      }
    },

    /**
     * Check if the sharelink is stale
     */
    pollProjectUpdates: function() {
      var me = this;
      // Get the query params to construct a request to check for staleness.
      var baseUrl = gomo.utility.getQueryParam('shareAppBaseUrl');
      var hash = gomo.utility.getQueryParam('shareHash');
      if (baseUrl && hash) {
        $.get(baseUrl + '/sharelink/' + hash + '/is-stale', function() {}).done(function(
          response
        ) {
          if (response.isStale && response.newShareLink.code) {
            me.newShareLink = response.newShareLink;
            me.warnUser();
          }
        })
          .fail(function(e) {
            if (window.LogManager) {
              window.LogManager.add('ERROR', e);
            }
          });
      }
    },

    /**
     * Warns the user the course data is stale and asks for confirmation to refresh.
     * @param {string} newHash
     */
    warnUser: function() {
      var me = this;
      me.disableAutoUpdate();
      var alertType = 'warning';
      var title = 'This course has been recently updated.';
      var message = 'Click Ok to reload the preview back to the beginning or click Cancel to'
      + ' continue with the current content and changes. Please note: the current content'
      + ' may be out-of-date and the media may fail to load.';
      var buttons = [
        {
          label: 'Cancel',
          type: 'secondary',
          action: function() {
            gomo.alertManager.create('danger', 'Reload for latest content.', false, false);
          }
        },
        {
          label: 'Ok',
          type: 'primary',
          action: function() {
            me.refreshCourse();
          }
        }
      ];
      gomo.alertManager.create(alertType, title, message, buttons);
    },

    /**
     * Refresh the course if the content becomes stale.
     */
    refreshCourse: function() {
      var me = this;

      var extras = {
        screenID: gomo.utility.getQueryParam('screenID'),
        topicID: gomo.utility.getQueryParam('topicID'),
        projectID: gomo.utility.getQueryParam('projectID'),
        groupID: gomo.utility.getQueryParam('groupID')
      };

      window.location.href = me.newShareLink.signingUrl + '?'
        + gomo.utility.objectToQueryString(extras);
    },

    disableAutoUpdate: function() {
      var me = this;
      clearInterval(me.dataPollingInterval);
    }

  };

  return new Preview();
})();

GOMO_PREVIEW.init();
